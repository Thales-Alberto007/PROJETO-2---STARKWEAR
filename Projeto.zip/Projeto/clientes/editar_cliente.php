<?php
require '../conexao.php';

// Se for envio do formulário (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id = $_POST['id_cliente'];
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
    $endereco = $_POST['endereco'];

    $sql = "UPDATE clientes SET 
                nome = '$nome',
                email = '$email',
                telefone = '$telefone',
                endereco = '$endereco'
            WHERE id_cliente = $id";

    if ($con->query($sql)) {
        header("Location: ../index.php");
        exit;
    } else {
        echo "Erro ao atualizar: " . $con->error;
    }
}

// Se NÃO for POST, significa que o usuário abriu para editar → pegar dados
$id = $_GET['id_cliente'];

$sql = "SELECT * FROM clientes WHERE id_cliente = $id";
$res = $con->query($sql);

if ($res->num_rows === 0) {
    die("Cliente não encontrado!");
}

$cliente = $res->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Editar Cliente</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 30px;
            background: #f5f5f5;
        }
        form {
            width: 350px;
            background: white;
            padding: 20px;
            border-radius: 6px;
            box-shadow: 0 0 6px rgba(0,0,0,0.1);
        }
        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 12px;
        }
        button {
            padding: 10px;
            width: 100%;
            background: #28a745;
            border: none;
            color: white;
            cursor: pointer;
            border-radius: 5px;
            font-weight: bold;
        }
        button:hover {
            background: #218838;
        }
    </style>
</head>
<body>

<h2>Editar Cliente</h2>

<form method="POST">
    <input type="hidden" name="id_cliente" value="<?= $cliente['id_cliente'] ?>">

    <input type="text" name="nome" value="<?= $cliente['nome'] ?>" required>
    <input type="email" name="email" value="<?= $cliente['email'] ?>" required>
    <input type="text" name="telefone" value="<?= $cliente['telefone'] ?>" required>
    <input type="text" name="endereco" value="<?= $cliente['endereco'] ?>" required>

    <button type="submit">Atualizar</button>
</form>

</body>
</html>
