<?php
require '../conexao.php';

$id = $_GET['id_cliente'];

$sql = "DELETE FROM clientes WHERE id_cliente = $id";

if ($con->query($sql)) {
    header("Location: ../index.php");
    exit;
} else {
    echo "Erro ao excluir: " . $con->error;
}
?>
