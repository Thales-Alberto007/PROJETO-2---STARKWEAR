<?php
require 'conexao.php';

$sql = "SELECT * FROM clientes";
$res = $con->query($sql);

$clientes = mysqli_fetch_all($res, MYSQLI_ASSOC);

echo json_encode($clientes);
