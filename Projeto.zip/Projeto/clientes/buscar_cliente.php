<?php
require 'conexao.php';

$pesquisa = $_GET['q'];

$sql = "SELECT * FROM clientes
        WHERE nome LIKE '%$pesquisa%' OR email LIKE '%$pesquisa%'";

$res = $con->query($sql);

echo json_encode(mysqli_fetch_all($res, MYSQLI_ASSOC));
