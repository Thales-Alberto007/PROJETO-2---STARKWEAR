<?php
require '../conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
    $endereco = $_POST['endereco'];

    $sql = "INSERT INTO clientes (nome, email, telefone, endereco)
            VALUES ('$nome', '$email', '$telefone', '$endereco')";

    if ($con->query($sql)) {
        header("Location: ../index.php");
        exit;
    } else {
        echo "Erro ao inserir: " . $con->error;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar Cliente</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 30px;
            background: #f5f5f5;
        }
        form {
            width: 350px;
            background: white;
            padding: 20px;
            border-radius: 6px;
            box-shadow: 0 0 6px rgba(0,0,0,0.1);
        }
        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 12px;
        }
        button {
            padding: 10px;
            width: 100%;
            background: #007bff;
            border: none;
            color: white;
            cursor: pointer;
            border-radius: 5px;
            font-weight: bold;
        }
        button:hover {
            background: #0069d9;
        }
    </style>
</head>
<body>

<h2>Cadastrar Novo Cliente</h2>

<form method="POST">
    <input type="text" name="nome" placeholder="Nome" required>
    <input type="email" name="email" placeholder="E-mail" required>
    <input type="text" name="telefone" placeholder="Telefone" required>
    <input type="text" name="endereco" placeholder="Endereço" required>

    <button type="submit">Salvar</button>
</form>

</body>
</html>