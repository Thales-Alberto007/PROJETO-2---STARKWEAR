<?php
require 'conexao.php';

/* =========================
   BUSCA CLIENTES
   ========================= */
$sqlClientes = "SELECT * FROM clientes";
$resClientes = $con->query($sqlClientes);
$clientes = mysqli_fetch_all($resClientes, MYSQLI_ASSOC);

/* =========================
   BUSCA REVIEWS
   ========================= */
$sqlReviews = "SELECT * FROM reviews";
$resReviews = $con->query($sqlReviews);
$reviews = mysqli_fetch_all($resReviews, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Clientes e Reviews</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        padding: 20px;
        background: #f5f5f5;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        background: white;
        margin-top: 20px;
        margin-bottom: 40px;
    }
    th, td {
        padding: 10px;
        border: 1px solid #ddd;
    }
    th {
        background: #eee;
    }
    td:last-child {
        width: 160px;
        text-align: center;
        white-space: nowrap;
    }

    .btn {
        display: inline-block;
        padding: 10px 14px;
        background: #28a745;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
    }
    .btn:hover {
        background: #218838;
    }

    .btn-listar {
        display: inline-block;
        padding: 10px 14px;
        background: #17a2b8;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
        margin-left: 10px;
    }
    .btn-listar:hover {
        background: #138496;
    }

    .btn-edit {
        padding: 6px 10px;
        background: #007bff;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        margin-right: 5px;
    }
    .btn-edit:hover {
        background: #0069d9;
    }

    .btn-delete {
        padding: 6px 10px;
        background: #dc3545;
        color: white;
        text-decoration: none;
        border-radius: 5px;
    }
    .btn-delete:hover {
        background: #c82333;
    }

    h3 {
        margin-top: 50px;
    }
    </style>
</head>
<body>

<h2>Lista de Clientes</h2>

<div style="margin-bottom: 20px;">
    <!-- Botão para adicionar cliente -->
    <a class="btn" href="clientes/criar_cliente.php">➕ Adicionar Cliente</a>

    <!-- Botão para adicionar review igual ao de adicionar cliente -->
    <a class="btn" href="reviews/criar_review.php">⭐ Adicionar Review</a>
</div>


<!-- =========================
     TABELA DE CLIENTES
     ========================= -->

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Email</th>
            <th>Telefone</th>
            <th>Endereço</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($clientes)): ?>
            <?php foreach ($clientes as $cli): ?>
                <tr>
                    <td><?= $cli['id_cliente'] ?></td>
                    <td><?= $cli['nome'] ?></td>
                    <td><?= $cli['email'] ?></td>
                    <td><?= $cli['telefone'] ?></td>
                    <td><?= $cli['endereco'] ?></td>
                    <td>
                        <a class="btn-edit" href="clientes/editar_cliente.php?id_cliente=<?= $cli['id_cliente'] ?>">Editar</a>
                        <a class="btn-delete" href="clientes/excluir_cliente.php?id_cliente=<?= $cli['id_cliente'] ?>"
                           onclick="return confirm('Tem certeza que deseja excluir este cliente?')">Excluir</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="6">Nenhum cliente encontrado.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<!-- =========================
     TABELA DE REVIEWS
     ========================= -->

<h3>Lista de Reviews</h3>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Nota</th>
            <th>Comentário</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($reviews)): ?>
            <?php foreach ($reviews as $rev): ?>
                <tr>
                    <td><?= $rev['id_review'] ?></td>
                    <td><?= $rev['nota'] ?></td>
                    <td><?= $rev['comentario'] ?></td>
                    <td>
                        <a class="btn-edit" href="reviews/editar_review.php?id_review=<?= $rev['id_review'] ?>">Editar</a>

                        <form action="reviews/excluir_review.php" method="POST" style="display:inline;">
                            <input type="hidden" name="id_review" value="<?= $rev['id_review'] ?>">
                            <button class="btn-delete" type="submit"
                                    onclick="return confirm('Excluir esta review?')">
                                Excluir
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="4">Nenhuma review encontrada.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

</body>
</html>
