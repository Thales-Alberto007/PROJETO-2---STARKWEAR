<?php
require_once __DIR__ . '/../conexao.php';

/* =========================
   ATUALIZA QUANDO ENVIA
   ========================= */
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $id_review  = (int) $_POST['id_review'];
    $nota       = $_POST['nota'];
    $comentario = $_POST['comentario'];

    $sqlUpdate = "UPDATE reviews SET
                  nota = '$nota',
                  comentario = '$comentario'
                  WHERE id_review = $id_review";

    if ($con->query($sqlUpdate)) {
        echo "<p style='color:green;'>Review atualizada com sucesso!</p>";
    } else {
        echo "<p style='color:red;'>Erro: " . $con->error . "</p>";
    }
}

/* =========================
   BUSCA DADOS PELO ID
   ========================= */
if (!isset($_GET['id_review'])) {
    die("ID não informado");
}

$id = (int) $_GET['id_review'];

$sql = "SELECT * FROM reviews WHERE id_review = $id";
$res = $con->query($sql);

if (!$res || $res->num_rows == 0) {
    die("Review não encontrada");
}

$review = $res->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Editar Review</title>
</head>
<body>

<h2>Editar Review</h2>

<form method="post">
    <input type="hidden" name="id_review" value="<?= $review['id_review'] ?>">

    <label>Nota:</label><br>
    <input type="number" name="nota" value="<?= $review['nota'] ?>" step="0.1" required><br><br>

    <label>Comentário:</label><br>
    <textarea name="comentario" required><?= $review['comentario'] ?></textarea><br><br>

    <button type="submit">Salvar Alterações</button>
</form>

<br>
<a href="listar_reviews.php">⬅ Voltar para lista</a>

</body>
</html>
