<?php
require '../conexao.php';

// Se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_cliente = intval($_POST['id_cliente']);
    $id_produto = intval($_POST['id_produto']);
    $nota = floatval($_POST['nota']);
    $comentario = trim($_POST['comentario']);

    // Inserir no banco de dados
    $stmt = $con->prepare("INSERT INTO reviews (id_cliente, id_produto, nota, comentario, data_review) VALUES (?, ?, ?, ?, NOW())");
    $stmt->bind_param("iids", $id_cliente, $id_produto, $nota, $comentario);

    if ($stmt->execute()) {
        echo "<p>Review cadastrada com sucesso!</p>";
        echo '<a href="index.php">⬅ Voltar</a>';
        exit;
    } else {
        echo "Erro: " . $stmt->error;
    }
}

// Buscar clientes e produtos para o formulário
$clientes = $con->query("SELECT id_cliente, nome FROM clientes")->fetch_all(MYSQLI_ASSOC);
$produtos = $con->query("SELECT id_produto, nome_produto FROM produtos")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Adicionar Review</title>
<style>
body { font-family: Arial; background: #f5f5f5; padding: 20px; }
label { display: block; margin-top: 10px; }
input, select, textarea { width: 300px; padding: 5px; margin-top: 5px; }
button { margin-top: 15px; padding: 10px 14px; background: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: bold; }
button:hover { background: #218838; }
</style>
</head>
<body>

<h2>Adicionar Review</h2>

<form action="" method="POST">
    <label>Cliente:</label>
    <select name="id_cliente" required>
        <option value="">Selecione</option>
        <?php foreach($clientes as $c): ?>
            <option value="<?= $c['id_cliente'] ?>"><?= htmlspecialchars($c['nome']) ?></option>
        <?php endforeach; ?>
    </select>

    <label>Produto:</label>
    <select name="id_produto" required>
        <option value="">Selecione</option>
        <?php foreach($produtos as $p): ?>
            <option value="<?= $p['id_produto'] ?>"><?= htmlspecialchars($p['nome_produto']) ?></option>
        <?php endforeach; ?>
    </select>

    <label>Nota (0 a 5):</label>
    <input type="number" name="nota" min="0" max="5" step="0.5" required>

    <label>Comentário:</label>
    <textarea name="comentario" rows="4"></textarea>

    <button type="submit">Salvar Review</button>
</form>

<br>
<a href="index.php">⬅ Voltar</a>

</body>
</html>
