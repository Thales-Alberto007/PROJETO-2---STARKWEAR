<?php
require '../conexao.php';

// CONSULTA CORRIGIDA COM LEFT JOIN + tratamento de erro
$sql = "SELECT r.id_review, r.nota, r.comentario, r.data_review,
               c.nome AS cliente,
               p.nome_produto AS produto
        FROM reviews r
        LEFT JOIN clientes c ON r.id_cliente = c.id_cliente
        LEFT JOIN produtos p ON r.id_produto = p.id_produto";

$res = $con->query($sql);

if (!$res) {
    die("Erro na consulta: " . $con->error);
}

$reviews = mysqli_fetch_all($res, MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang=\"pt-BR\">
<head>
    <meta charset=\"UTF-8\">
    <title>Lista de Reviews</title>
    <style>
        body { font-family: Arial; background: #f5f5f5; padding: 20px; }
        table { width: 100%; background: white; border-collapse: collapse; }
        th, td { padding: 10px; border: 1px solid #ddd; }
        th { background: #eee; }
        .btn-edit {
            padding: 6px 10px;
            background: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin-right: 5px;
        }
        .btn-edit:hover { background: #0069d9; }
        .btn-delete {
            padding: 6px 10px;
            background: #dc3545;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }
        .btn-delete:hover { background: #c82333; }
    </style>
</head>
<body>

<h2>Lista de Reviews</h2>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Cliente</th>
            <th>Produto</th>
            <th>Nota</th>
            <th>Comentário</th>
            <th>Data</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($reviews)): ?>
            <?php foreach ($reviews as $r): ?>
                <tr>
                    <td><?= $r['id_review'] ?></td>
                    <td><?= $r['cliente'] ?? 'Sem cliente' ?></td>
                    <td><?= $r['produto'] ?? 'Sem produto' ?></td>
                    <td><?= $r['nota'] ?></td>
                    <td><?= $r['comentario'] ?></td>
                    <td><?= $r['data_review'] ?></td>
                    <td>
                        <a class=\"btn-edit\" href=\"editar_review.php?id_review=<?= $r['id_review'] ?>\">Editar</a>
                        <a class=\"btn-delete\" href=\"excluir_review.php?id_review=<?= $r['id_review'] ?>\"
                           onclick=\"return confirm('Excluir esta review?')\">Excluir</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan=\"7\">Nenhuma review encontrada.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

</body>
</html>
