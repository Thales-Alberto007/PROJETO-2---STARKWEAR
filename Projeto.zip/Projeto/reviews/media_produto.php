<?php
require 'conexao.php';

// Query para buscar média de notas por produto
$sql = "SELECT p.id_produto, p.nome_produto, AVG(r.nota) AS media
        FROM produtos p
        LEFT JOIN reviews r ON p.id_produto = r.id_produto
        GROUP BY p.id_produto, p.nome_produto
        ORDER BY p.nome_produto";

$res = $con->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Média das Notas por Produto</title>
<style>
body { font-family: Arial; background: #f5f5f5; padding: 20px; }
table { width: 100%; background: white; border-collapse: collapse; margin-top: 20px; }
th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
th { background: #eee; }
.btn {
    display: inline-block;
    padding: 10px 14px;
    background: #28a745;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-weight: bold;
}
.btn:hover { background: #218838; }
</style>
</head>
<body>

<h2>Média das Notas por Produto</h2>

<a class="btn" href="index.php">⬅ Voltar</a>

<table>
<thead>
    <tr>
        <th>Produto</th>
        <th>Média</th>
    </tr>
</thead>
<tbody>
<?php while($row = $res->fetch_assoc()): ?>
    <tr>
        <td><?= htmlspecialchars($row['nome_produto']) ?></td>
        <td>
            <?php
            if ($row['media'] === null) {
                echo "Sem avaliações";
            } else {
                echo number_format($row['media'], 1) . " ⭐";
            }
            ?>
        </td>
    </tr>
<?php endwhile; ?>
</tbody>
</table>

</body>
</html>
