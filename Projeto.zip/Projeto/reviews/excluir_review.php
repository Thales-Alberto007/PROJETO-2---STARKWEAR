<?php
require_once __DIR__ . '/../conexao.php';

if (!isset($_POST['id_review'])) {
    die("ID não recebido.");
}

$id_review = (int) $_POST['id_review'];

$sql = "DELETE FROM reviews WHERE id_review = $id_review";

if ($con->query($sql)) {
    // volta para o index depois de excluir
    header("Location: ../index.php");
    exit;
} else {
    echo "Erro ao excluir: " . $con->error;
}
