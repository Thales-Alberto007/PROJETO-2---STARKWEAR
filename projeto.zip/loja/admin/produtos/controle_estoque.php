<?php
include "conexao.php";

if(isset($_GET['incrementar'])){
    $id = $_GET['incrementar'];
    $qtd = intval($_GET['qtd']) ?: 1;
    $con->query("UPDATE produtos SET estoque = estoque + $qtd WHERE id_produto = $id");
    header("Location: controle_estoque.php");
    exit;
}

if(isset($_GET['decrementar'])){
    $id = $_GET['decrementar'];
    $qtd = intval($_GET['qtd']) ?: 1;
    $con->query("UPDATE produtos SET estoque = GREATEST(estoque - $qtd, 0) WHERE id_produto = $id");
    header("Location: controle_estoque.php");
    exit;
}

$produtos = $con->query("SELECT * FROM produtos");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Controle de Estoque</title>
<style>
body{font-family:Arial;margin:20px}
table{border-collapse:collapse;width:100%}
table th, table td{border:1px solid #999;padding:8px;text-align:center}
table th{background:#eee}
input[type=number]{width:60px;padding:3px}
a.button{padding:5px 10px;background:#4CAF50;color:white;text-decoration:none;border-radius:3px;margin:2px}
a.button.red{background:#f44336}
</style>
</head>
<body>

<h2>Controle de Estoque</h2>
<table>
<tr>
<th>ID</th>
<th>Produto</th>
<th>Estoque Atual</th>
<th>Quantidade</th>
<th>Ações</th>
</tr>

<?php while($p = $produtos->fetch_assoc()): ?>
<tr>
<td><?= $p['id_produto'] ?></td>
<td><?= $p['nome_produto'] ?></td>
<td><?= $p['estoque'] ?></td>
<td>
<form method="get" style="display:inline">
<input type="number" name="qtd" value="1" min="1">
<input type="hidden" name="incrementar" value="<?= $p['id_produto'] ?>">
<button type="submit">+</button>
</form>
<form method="get" style="display:inline">
<input type="number" name="qtd" value="1" min="1">
<input type="hidden" name="decrementar" value="<?= $p['id_produto'] ?>">
<button type="submit">-</button>
</form>
</td>
<td>
<a href="controle_estoque.php?incrementar=<?= $p['id_produto'] ?>&qtd=1" class="button">+1</a>
<a href="controle_estoque.php?decrementar=<?= $p['id_produto'] ?>&qtd=1" class="button red">-1</a>
</td>
</tr>
<?php endwhile; ?>
</table>

</body>
</html>
