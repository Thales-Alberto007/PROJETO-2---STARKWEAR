<?php
include "conexao.php";

$produtos = $con->query("
    SELECT p.id_produto, p.nome_produto, p.descricao_produto, p.preco, p.preco_promocional, p.imagem_produto,
           COUNT(r.id_review) AS total_vendas
    FROM produtos p
    LEFT JOIN reviews r ON p.id_produto = r.id_produto
    GROUP BY p.id_produto
    ORDER BY total_vendas DESC
");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Produtos Mais Vendidos</title>
<style>
body{font-family:Arial;margin:20px}
table{border-collapse:collapse;width:100%}
table th, table td{border:1px solid #999;padding:8px;text-align:center}
table th{background:#eee}
img{max-width:80px;height:auto}
</style>
</head>
<body>

<h2>Produtos Mais Vendidos</h2>
<table>
<tr>
<th>ID</th>
<th>Nome</th>
<th>Descrição</th>
<th>Preço</th>
<th>Preço Promo</th>
<th>Total de Vendas</th>
<th>Imagem</th>
</tr>

<?php while($p = $produtos->fetch_assoc()): ?>
<tr>
<td><?= $p['id_produto'] ?></td>
<td><?= $p['nome_produto'] ?></td>
<td><?= $p['descricao_produto'] ?></td>
<td><?= $p['preco'] ?></td>
<td><?= $p['preco_promocional'] ?></td>
<td><?= $p['total_vendas'] ?></td>
<td><?php if(!empty($p['imagem_produto'])): ?><img src="uploads/<?= $p['imagem_produto'] ?>" alt=""><?php endif; ?></td>
</tr>
<?php endwhile; ?>
</table>

</body>
</html>
