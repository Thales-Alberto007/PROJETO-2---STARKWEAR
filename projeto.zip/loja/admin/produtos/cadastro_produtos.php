<?php
include "conexao.php";

// Função para apagar produto
if(isset($_GET['apagar'])){
    $id = $_GET['apagar'];
    
    // Primeiro pegar o nome da imagem para deletar do servidor
    $res = $con->query("SELECT imagem_produto FROM produtos WHERE id_produto = $id");
    if($res && $res->num_rows > 0){
        $row = $res->fetch_assoc();
        if(!empty($row['imagem_produto']) && file_exists("uploads/".$row['imagem_produto'])){
            unlink("uploads/".$row['imagem_produto']);
        }
    }

    $con->query("DELETE FROM produtos WHERE id_produto = $id");
    header("Location: cadastro_produtos.php");
    exit;
}

// Função para editar produto
if(isset($_GET['editar'])){
    $id_editar = $_GET['editar'];
    $res_editar = $con->query("SELECT * FROM produtos WHERE id_produto = $id_editar");
    $produto_edit = $res_editar->fetch_assoc();
}

// Pega todas as coleções e estampas para os selects
$colecoes = $con->query("SELECT id_colecao, nome_colecao FROM colecoes");
$estampas = $con->query("SELECT id_estampa, nome_estampa FROM estampas");

// Processa o formulário de cadastro ou edição
if($_SERVER['REQUEST_METHOD'] == "POST"){
    $nome = $_POST['nome_produto'];
    $descricao = $_POST['descricao_produto'];
    $preco = $_POST['preco'];
    $preco_promocional = $_POST['preco_promocional'];
    $estoque = $_POST['estoque'];
    $tamanho = $_POST['tamanho'];
    $id_colecao = $_POST['id_colecao'];
    $id_estampa = $_POST['id_estampa'];

    // Upload de imagem
    $imagem = isset($produto_edit['imagem_produto']) ? $produto_edit['imagem_produto'] : null;
    if(isset($_FILES['imagem_produto']) && $_FILES['imagem_produto']['error'] == 0){
        $arquivo = $_FILES['imagem_produto'];
        $pasta = "uploads/";
        $nome_arquivo = time() . "_" . $arquivo['name'];
        $caminho = $pasta . $nome_arquivo;

        if(move_uploaded_file($arquivo['tmp_name'], $caminho)){
            // Apaga imagem antiga caso esteja editando
            if(isset($produto_edit['imagem_produto']) && file_exists($pasta.$produto_edit['imagem_produto'])){
                unlink($pasta.$produto_edit['imagem_produto']);
            }
            $imagem = $nome_arquivo;
        }
    }

    if(isset($_POST['id_produto']) && !empty($_POST['id_produto'])){
        // Atualiza produto existente
        $id = $_POST['id_produto'];
        $sql = "UPDATE produtos SET 
                    nome_produto='$nome', 
                    descricao_produto='$descricao', 
                    preco='$preco', 
                    preco_promocional='$preco_promocional', 
                    estoque='$estoque', 
                    tamanho='$tamanho', 
                    imagem_produto='$imagem', 
                    id_colecao='$id_colecao', 
                    id_estampa='$id_estampa' 
                WHERE id_produto=$id";
    } else {
        // Insere novo produto
        $sql = "INSERT INTO produtos (nome_produto, descricao_produto, preco, preco_promocional, estoque, tamanho, imagem_produto, id_colecao, id_estampa) 
                VALUES ('$nome','$descricao','$preco','$preco_promocional','$estoque','$tamanho','$imagem','$id_colecao','$id_estampa')";
    }

    if($con->query($sql)){
        header("Location: cadastro_produtos.php");
        exit;
    }
}

// Lista todos os produtos
$produtos = $con->query("SELECT p.*, c.nome_colecao, e.nome_estampa 
                         FROM produtos p 
                         JOIN colecoes c ON p.id_colecao = c.id_colecao 
                         JOIN estampas e ON p.id_estampa = e.id_estampa");
?>

<h2><?= isset($produto_edit) ? "Editar Produto" : "Cadastrar Produto" ?></h2>

<form action="" method="post" enctype="multipart/form-data">
    <input type="hidden" name="id_produto" value="<?= isset($produto_edit) ? $produto_edit['id_produto'] : '' ?>">
    
    <label>Nome do Produto:</label><br>
    <input type="text" name="nome_produto" value="<?= isset($produto_edit) ? $produto_edit['nome_produto'] : '' ?>" required><br><br>

    <label>Descrição:</label><br>
    <textarea name="descricao_produto"><?= isset($produto_edit) ? $produto_edit['descricao_produto'] : '' ?></textarea><br><br>

    <label>Preço:</label><br>
    <input type="number" step="0.01" name="preco" value="<?= isset($produto_edit) ? $produto_edit['preco'] : '' ?>" required><br><br>

    <label>Preço Promocional:</label><br>
    <input type="number" step="0.01" name="preco_promocional" value="<?= isset($produto_edit) ? $produto_edit['preco_promocional'] : '' ?>"><br><br>

    <label>Estoque:</label><br>
    <input type="number" name="estoque" value="<?= isset($produto_edit) ? $produto_edit['estoque'] : '' ?>" required><br><br>

    <label>Tamanho:</label><br>
    <select name="tamanho" required>
        <?php
        $tamanhos = ['P','M','G','GG'];
        foreach($tamanhos as $t){
            $selected = (isset($produto_edit) && $produto_edit['tamanho'] == $t) ? "selected" : "";
            echo "<option value='$t' $selected>$t</option>";
        }
        ?>
    </select><br><br>

    <label>Coleção:</label><br>
    <select name="id_colecao" required>
        <option value="">Selecione</option>
        <?php
        $colecoes->data_seek(0); // reinicia o fetch
        while($c = $colecoes->fetch_assoc()){
            $selected = (isset($produto_edit) && $produto_edit['id_colecao'] == $c['id_colecao']) ? "selected" : "";
            echo "<option value='{$c['id_colecao']}' $selected>{$c['nome_colecao']}</option>";
        }
        ?>
    </select><br><br>

    <label>Estampa:</label><br>
    <select name="id_estampa" required>
        <option value="">Selecione</option>
        <?php
        $estampas->data_seek(0); // reinicia o fetch
        while($e = $estampas->fetch_assoc()){
            $selected = (isset($produto_edit) && $produto_edit['id_estampa'] == $e['id_estampa']) ? "selected" : "";
            echo "<option value='{$e['id_estampa']}' $selected>{$e['nome_estampa']}</option>";
        }
        ?>
    </select><br><br>

    <label>Imagem do Produto:</label><br>
    <input type="file" name="imagem_produto"><br>
    <?php if(isset($produto_edit) && !empty($produto_edit['imagem_produto'])): ?>
        <img src="uploads/<?= $produto_edit['imagem_produto'] ?>" width="100">
    <?php endif; ?>
    <br><br>

    <button type="submit"><?= isset($produto_edit) ? "Atualizar Produto" : "Cadastrar Produto" ?></button>
</form>

<hr>

<h2>Produtos Cadastrados</h2>
<table border="1" cellpadding="5" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Preço</th>
        <th>Estoque</th>
        <th>Tamanho</th>
        <th>Coleção</th>
        <th>Estampa</th>
        <th>Imagem</th>
        <th>Ações</th>
    </tr>
    <?php while($p = $produtos->fetch_assoc()): ?>
    <tr>
        <td><?= $p['id_produto'] ?></td>
        <td><?= $p['nome_produto'] ?></td>
        <td><?= $p['preco'] ?></td>
        <td><?= $p['estoque'] ?></td>
        <td><?= $p['tamanho'] ?></td>
        <td><?= $p['nome_colecao'] ?></td>
        <td><?= $p['nome_estampa'] ?></td>
        <td>
            <?php if(!empty($p['imagem_produto'])): ?>
                <img src="uploads/<?= $p['imagem_produto'] ?>" width="50">
            <?php endif; ?>
        </td>
        <td>
            <a href="?editar=<?= $p['id_produto'] ?>">Editar</a> | 
            <a href="?apagar=<?= $p['id_produto'] ?>" onclick="return confirm('Deseja realmente apagar este produto?')">Apagar</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
