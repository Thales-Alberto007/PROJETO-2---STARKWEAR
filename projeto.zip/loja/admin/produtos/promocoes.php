<?php
include "conexao.php";

$colecoes = $con->query("SELECT id_colecao, nome_colecao, desconto FROM colecoes");
$estampas = $con->query("SELECT id_estampa, nome_estampa FROM estampas");

if(isset($_GET['apagar'])){
    $id = $_GET['apagar'];
    $res = $con->query("SELECT imagem_produto FROM produtos WHERE id_produto = $id");
    if($res && $res->num_rows > 0){
        $row = $res->fetch_assoc();
        if(!empty($row['imagem_produto']) && file_exists("uploads/".$row['imagem_produto'])){
            unlink("uploads/".$row['imagem_produto']);
        }
    }
    $con->query("DELETE FROM produtos WHERE id_produto = $id");
    header("Location: cadastro_produtos_promocao.php");
    exit;
}

if(isset($_GET['editar'])){
    $id_editar = $_GET['editar'];
    $res_editar = $con->query("SELECT * FROM produtos WHERE id_produto = $id_editar");
    $produto_edit = $res_editar->fetch_assoc();
}

if($_SERVER['REQUEST_METHOD'] == "POST"){
    $nome = $_POST['nome_produto'];
    $descricao = $_POST['descricao_produto'];
    $preco = $_POST['preco'];
    $estoque = $_POST['estoque'];
    $tamanho = $_POST['tamanho'];
    $id_colecao = $_POST['id_colecao'];
    $id_estampa = $_POST['id_estampa'];

    $res_colecao = $con->query("SELECT desconto FROM colecoes WHERE id_colecao = $id_colecao");
    $desconto = 0;
    if($res_colecao && $res_colecao->num_rows > 0){
        $row_desconto = $res_colecao->fetch_assoc();
        $desconto = $row_desconto['desconto'];
    }

    $preco_promocional = $preco - ($preco * ($desconto / 100));

    $imagem = isset($produto_edit['imagem_produto']) ? $produto_edit['imagem_produto'] : null;
    if(isset($_FILES['imagem_produto']) && $_FILES['imagem_produto']['error'] == 0){
        $arquivo = $_FILES['imagem_produto'];
        $pasta = "uploads/";
        $nome_arquivo = time() . "_" . $arquivo['name'];
        $caminho = $pasta . $nome_arquivo;
        if(move_uploaded_file($arquivo['tmp_name'], $caminho)){
            if(isset($produto_edit['imagem_produto']) && file_exists($pasta.$produto_edit['imagem_produto'])){
                unlink($pasta.$produto_edit['imagem_produto']);
            }
            $imagem = $nome_arquivo;
        }
    }

    if(isset($_POST['id_produto']) && !empty($_POST['id_produto'])){
        $id = $_POST['id_produto'];
        $sql = "UPDATE produtos SET 
                    nome_produto='$nome',
                    descricao_produto='$descricao',
                    preco='$preco',
                    preco_promocional='$preco_promocional',
                    estoque='$estoque',
                    tamanho='$tamanho',
                    imagem_produto='$imagem',
                    id_colecao='$id_colecao',
                    id_estampa='$id_estampa'
                WHERE id_produto=$id";
    } else {
        $sql = "INSERT INTO produtos 
                (nome_produto, descricao_produto, preco, preco_promocional, estoque, tamanho, imagem_produto, id_colecao, id_estampa)
                VALUES ('$nome','$descricao','$preco','$preco_promocional','$estoque','$tamanho','$imagem','$id_colecao','$id_estampa')";
    }

    if($con->query($sql)){
        header("Location: cadastro_produtos_promocao.php");
        exit;
    }
}

$produtos = $con->query("SELECT p.*, c.nome_colecao, e.nome_estampa 
                         FROM produtos p 
                         JOIN colecoes c ON p.id_colecao = c.id_colecao 
                         JOIN estampas e ON p.id_estampa = e.id_estampa");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Cadastro Produtos com Promoção</title>
<style>
body{font-family:Arial;margin:20px}
input,textarea,select,button{padding:5px;margin-bottom:10px;width:300px}
button{width:auto;cursor:pointer}
table{border-collapse:collapse;width:100%;margin-top:30px}
table th,table td{border:1px solid #999;padding:8px;text-align:center}
table th{background:#eee}
img{max-width:100px;height:auto}
</style>
</head>
<body>

<h2><?= isset($produto_edit) ? "Editar Produto" : "Cadastrar Produto" ?></h2>
<form action="" method="post" enctype="multipart/form-data">
<input type="hidden" name="id_produto" value="<?= isset($produto_edit) ? $produto_edit['id_produto'] : '' ?>">

<label>Nome do Produto:</label><br>
<input type="text" name="nome_produto" value="<?= isset($produto_edit) ? $produto_edit['nome_produto'] : '' ?>" required><br>

<label>Descrição:</label><br>
<textarea name="descricao_produto"><?= isset($produto_edit) ? $produto_edit['descricao_produto'] : '' ?></textarea><br>

<label>Preço:</label><br>
<input type="number" step="0.01" name="preco" value="<?= isset($produto_edit) ? $produto_edit['preco'] : '' ?>" required><br>

<label>Estoque:</label><br>
<input type="number" name="estoque" value="<?= isset($produto_edit) ? $produto_edit['estoque'] : '' ?>" required><br>

<label>Tamanho:</label><br>
<select name="tamanho" required>
<?php
$tamanhos = ['P','M','G','GG'];
foreach($tamanhos as $t){
    $selected = (isset($produto_edit) && $produto_edit['tamanho'] == $t) ? "selected" : "";
    echo "<option value='$t' $selected>$t</option>";
}
?>
</select><br>

<label>Coleção:</label><br>
<select name="id_colecao" required>
<option value="">Selecione</option>
<?php
$colecoes->data_seek(0);
while($c = $colecoes->fetch_assoc()){
    $selected = (isset($produto_edit) && $produto_edit['id_colecao'] == $c['id_colecao']) ? "selected" : "";
    echo "<option value='{$c['id_colecao']}' $selected>{$c['nome_colecao']}</option>";
}
?>
</select><br>

<label>Estampa:</label><br>
<select name="id_estampa" required>
<option value="">Selecione</option>
<?php
$estampas->data_seek(0);
while($e = $estampas->fetch_assoc()){
    $selected = (isset($produto_edit) && $produto_edit['id_estampa'] == $e['id_estampa']) ? "selected" : "";
    echo "<option value='{$e['id_estampa']}' $selected>{$e['nome_estampa']}</option>";
}
?>
</select><br>

<label>Imagem do Produto:</label><br>
<input type="file" name="imagem_produto"><br>
<?php if(isset($produto_edit) && !empty($produto_edit['imagem_produto'])): ?>
<img src="uploads/<?= $produto_edit['imagem_produto'] ?>" alt=""><br>
<?php endif; ?>

<button type="submit"><?= isset($produto_edit) ? "Atualizar Produto" : "Cadastrar Produto" ?></button>
</form>

<h2>Produtos Cadastrados</h2>
<table>
<tr>
<th>ID</th><th>Nome</th><th>Preço</th><th>Promoção</th><th>Estoque</th><th>Tamanho</th><th>Coleção</th><th>Estampa</th><th>Imagem</th><th>Ações</th>
</tr>
<?php while($p = $produtos->fetch_assoc()): ?>
<tr>
<td><?= $p['id_produto'] ?></td>
<td><?= $p['nome_produto'] ?></td>
<td><?= $p['preco'] ?></td>
<td><?= $p['preco_promocional'] ?></td>
<td><?= $p['estoque'] ?></td>
<td><?= $p['tamanho'] ?></td>
<td><?= $p['nome_colecao'] ?></td>
<td><?= $p['nome_estampa'] ?></td>
<td><?php if(!empty($p['imagem_produto'])): ?><img src="uploads/<?= $p['imagem_produto'] ?>" alt=""><?php endif; ?></td>
<td><a href="?editar=<?= $p['id_produto'] ?>">Editar</a> | <a href="?apagar=<?= $p['id_produto'] ?>" onclick="return confirm('Deseja realmente apagar este produto?')">Apagar</a></td>
</tr>
<?php endwhile; ?>
</table>

</body>
</html>
