<?php
include "conexao.php";

$estampas = $con->query("SELECT id_estampa, nome_estampa FROM estampas");

$id_estampa = isset($_GET['id_estampa']) ? intval($_GET['id_estampa']) : 0;

if($id_estampa > 0){
    $produtos = $con->query("SELECT p.*, c.nome_colecao 
                             FROM produtos p 
                             JOIN colecoes c ON p.id_colecao = c.id_colecao
                             WHERE p.id_estampa = $id_estampa");
} else {
    $produtos = $con->query("SELECT p.*, c.nome_colecao 
                             FROM produtos p 
                             JOIN colecoes c ON p.id_colecao = c.id_colecao");
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Produtos por Estampa</title>
<style>
body{font-family:Arial;margin:20px}
select{padding:5px;margin-bottom:15px}
table{border-collapse:collapse;width:100%}
table th, table td{border:1px solid #999;padding:8px;text-align:center}
table th{background:#eee}
img{max-width:80px;height:auto}
</style>
</head>
<body>

<h2>Produtos por Estampa</h2>
<form method="get">
<label>Escolha a Estampa:</label>
<select name="id_estampa" onchange="this.form.submit()">
<option value="0">Todas as Estampas</option>
<?php while($e = $estampas->fetch_assoc()): ?>
<option value="<?= $e['id_estampa'] ?>" <?= ($id_estampa == $e['id_estampa']) ? 'selected' : '' ?>><?= $e['nome_estampa'] ?></option>
<?php endwhile; ?>
</select>
</form>

<table>
<tr>
<th>ID</th>
<th>Nome</th>
<th>Descrição</th>
<th>Preço</th>
<th>Preço Promo</th>
<th>Coleção</th>
<th>Imagem</th>
</tr>

<?php while($p = $produtos->fetch_assoc()): ?>
<tr>
<td><?= $p['id_produto'] ?></td>
<td><?= $p['nome_produto'] ?></td>
<td><?= $p['descricao_produto'] ?></td>
<td><?= $p['preco'] ?></td>
<td><?= $p['preco_promocional'] ?></td>
<td><?= $p['nome_colecao'] ?></td>
<td><?php if(!empty($p['imagem_produto'])): ?><img src="uploads/<?= $p['imagem_produto'] ?>" alt=""><?php endif; ?></td>
</tr>
<?php endwhile; ?>
</table>

</body>
</html>
