<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Starkwear</title>
</head>
<body>

    <?php
        echo "<h2>Starkwear</h2>";

        echo "<p>Bem-vindo à Starkwear, uma marca criada para quem acredita que estilo e personalidade caminham juntos. Aqui, cada camisa é pensada para trazer conforto, qualidade e um toque único que combina com seu dia a dia.<br><br>

        Nossa loja nasce da vontade de oferecer peças modernas, acessíveis e feitas para durar. Trabalhamos com materiais de alta qualidade e estampas exclusivas, desenvolvidas para quem gosta de se expressar através da moda — seja no casual, no streetwear ou naquele visual mais ousado.<br><br>

        Na Starkwear, acreditamos que roupa é muito mais que tecido: é identidade. Por isso, buscamos sempre unir criatividade, bom gosto e compromisso com cada cliente que passa por aqui.<br><br>

        Seja para renovar o guarda-roupa, montar um estilo novo ou garantir aquela camisa que combina totalmente com você, estamos aqui para entregar o melhor.<br>
        Sinta-se em casa. Sinta-se Starkwear.</p>";
    ?>

</body>
</html>
