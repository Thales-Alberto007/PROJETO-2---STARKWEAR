# Projeto PHP + MySQL

Banco: projeto1  
Dump: sql/projeto1.sql  

Para restaurar o banco:
mysql -u root -p projeto1 < sql/projeto1.sql

Copie o projeto para a pasta htdocs e acesse:
http://localhost/projeto1